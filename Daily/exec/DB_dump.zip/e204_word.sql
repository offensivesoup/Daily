-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11e204.p.ssafy.io    Database: e204
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `word`
--

DROP TABLE IF EXISTS `word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `word` (
  `id` int NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `word` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `word`
--

LOCK TABLES `word` WRITE;
/*!40000 ALTER TABLE `word` DISABLE KEYS */;
INSERT INTO `word` VALUES (1,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-1.png','가수'),(2,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-2.png','가운'),(3,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-3.png','가재'),(4,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-4.png','가지'),(5,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-5.png','간호사'),(6,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-6.png','감'),(7,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-7.png','감자'),(8,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-8.png','강아지'),(9,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-9.png','거품기'),(10,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-10.png','경찰관'),(11,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-11.png','경찰차'),(12,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-12.png','고구마'),(13,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-13.png','고래'),(14,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-14.png','고양이'),(15,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-15.png','고추'),(16,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-16.png','과학자'),(17,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-17.png','구급차'),(18,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-18.png','국자'),(19,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-19.png','군인'),(20,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-20.png','귤'),(21,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-21.png','꽃게'),(22,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-22.png','꿀벌'),(23,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-23.png','나비'),(24,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-24.png','나팔'),(25,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-25.png','나팔꽃'),(26,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-26.png','냄비'),(27,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-27.png','농부'),(28,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-28.png','달팽이'),(29,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-29.png','닭'),(30,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-30.png','당근'),(31,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-31.png','돌고래'),(32,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-32.png','돼지'),(33,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-33.png','뒤집개'),(34,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-34.png','딸기'),(35,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-35.png','리코더'),(36,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-36.png','마스크'),(37,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-37.png','말'),(38,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-38.png','목도리'),(39,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-39.png','문어'),(40,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-40.png','물고기'),(41,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-41.png','바나나'),(43,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-43.png','바지'),(45,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-45.png','배'),(46,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-46.png','배추'),(47,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-47.png','뱀'),(48,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-48.png','버섯'),(49,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-49.png','병아리'),(50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-50.png','북'),(52,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-52.png','불도저'),(53,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-53.png','비행기'),(54,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-54.png','사과'),(56,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-56.png','사진사'),(57,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-57.png','새우'),(58,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-58.png','색연필'),(59,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-59.png','선생님'),(60,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-60.png','소방관'),(61,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-61.png','소방차'),(62,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-62.png','수박'),(63,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-63.png','숟가락'),(64,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-64.png','실로폰'),(65,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-65.png','심벌즈'),(67,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-67.png','양'),(68,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-68.png','양말'),(69,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-69.png','양파'),(70,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-70.png','연필'),(71,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-71.png','오리'),(72,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-72.png','오이'),(73,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-73.png','오징어'),(74,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-74.png','요리사'),(75,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-75.png','용'),(76,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-76.png','원숭이'),(77,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-77.png','원피스'),(78,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-78.png','의사'),(80,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-80.png','자동차'),(81,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-81.png','잠옷'),(82,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-82.png','장갑'),(83,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-83.png','장미'),(84,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-84.png','젓가락'),(85,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-85.png','조개'),(86,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-86.png','주걱'),(87,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-87.png','주방'),(88,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-88.png','주전자'),(89,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-89.png','쥐'),(90,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-90.png','지우개'),(91,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-91.png','집배원'),(92,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-92.png','참외'),(93,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-93.png','체리'),(95,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-95.png','치마'),(96,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-96.png','코끼리'),(97,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-97.png','키위'),(98,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-98.png','타조'),(99,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-99.png','탬버린'),(100,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-100.png','털모자'),(101,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-101.png','튤립'),(102,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-102.png','티셔츠'),(103,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-103.png','포도'),(104,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-104.png','포크'),(106,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-106.png','피아노'),(107,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-107.png','하마'),(110,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-110.png','호랑이'),(111,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/word-111.png','화가');
/*!40000 ALTER TABLE `word` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 18:57:08
