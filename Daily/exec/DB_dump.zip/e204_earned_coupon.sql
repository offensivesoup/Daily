-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11e204.p.ssafy.io    Database: e204
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `earned_coupon`
--

DROP TABLE IF EXISTS `earned_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `earned_coupon` (
  `member_id` int NOT NULL,
  `coupon_id` bigint NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `used_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb5i31pb8otjve6bs153qoi7pv` (`coupon_id`),
  KEY `FKj3rc5qn8b48q77fbggenwbh33` (`member_id`),
  CONSTRAINT `FKb5i31pb8otjve6bs153qoi7pv` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`id`),
  CONSTRAINT `FKj3rc5qn8b48q77fbggenwbh33` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `earned_coupon`
--

LOCK TABLES `earned_coupon` WRITE;
/*!40000 ALTER TABLE `earned_coupon` DISABLE KEYS */;
INSERT INTO `earned_coupon` VALUES (11,15,14,NULL),(12,19,15,'2024-11-14 12:13:59.468495'),(12,20,16,NULL),(25,49,29,'2024-11-16 15:30:24.552011'),(25,50,33,NULL),(25,51,34,NULL),(115,61,37,'2024-11-18 01:32:47.860490'),(112,65,38,NULL),(25,43,39,'2024-11-18 09:13:37.321476'),(25,55,40,NULL),(35,84,42,'2024-11-18 14:09:47.683502'),(32,82,43,'2024-11-18 14:11:23.816060'),(129,74,44,'2024-11-18 14:17:40.959055'),(36,79,45,'2024-11-18 14:26:13.015959');
/*!40000 ALTER TABLE `earned_coupon` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 18:57:06
