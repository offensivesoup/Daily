-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11e204.p.ssafy.io    Database: e204
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quest`
--

DROP TABLE IF EXISTS `quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quest` (
  `diary_status` bit(1) NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `quiz_status` bit(1) NOT NULL,
  `word_status` bit(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtn53x2bl1cya9kwvwbcdk4ww4` (`member_id`),
  CONSTRAINT `FKtn53x2bl1cya9kwvwbcdk4ww4` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest`
--

LOCK TABLES `quest` WRITE;
/*!40000 ALTER TABLE `quest` DISABLE KEYS */;
INSERT INTO `quest` VALUES (_binary '\0',6,7,_binary '\0',_binary '\0','2024-11-13 10:57:00.374839'),(_binary '\0',10,11,_binary '\0',_binary '\0','2024-11-13 23:15:46.298350'),(_binary '\0',11,12,_binary '\0',_binary '\0','2024-11-13 23:16:23.186233'),(_binary '\0',15,16,_binary '\0',_binary '\0','2024-11-14 12:02:46.210216'),(_binary '\0',16,17,_binary '\0',_binary '\0','2024-11-14 12:21:14.150423'),(_binary '\0',17,18,_binary '\0',_binary '\0','2024-11-14 12:44:58.055877'),(_binary '',24,25,_binary '\0',_binary '\0','2024-11-15 09:52:36.971199'),(_binary '\0',26,27,_binary '\0',_binary '\0','2024-11-15 09:52:53.994537'),(_binary '',27,28,_binary '\0',_binary '','2024-11-15 09:53:15.991520'),(_binary '',29,30,_binary '',_binary '\0','2024-11-15 10:06:07.917991'),(_binary '',30,31,_binary '\0',_binary '\0','2024-11-15 10:06:18.228293'),(_binary '',31,32,_binary '',_binary '','2024-11-15 10:06:27.267165'),(_binary '',34,35,_binary '',_binary '','2024-11-15 11:14:10.560957'),(_binary '\0',35,36,_binary '\0',_binary '','2024-11-15 11:21:32.920773'),(_binary '\0',81,82,_binary '\0',_binary '\0','2024-11-17 02:34:08.538427'),(_binary '\0',82,83,_binary '\0',_binary '\0','2024-11-17 04:37:08.158863'),(_binary '\0',84,85,_binary '\0',_binary '\0','2024-11-17 16:55:14.851109'),(_binary '\0',85,86,_binary '\0',_binary '\0','2024-11-17 16:56:54.028319'),(_binary '\0',92,93,_binary '\0',_binary '\0','2024-11-17 18:21:47.654253'),(_binary '\0',93,94,_binary '\0',_binary '\0','2024-11-17 18:21:56.729215'),(_binary '\0',95,96,_binary '\0',_binary '\0','2024-11-17 21:55:39.848196'),(_binary '\0',109,110,_binary '\0',_binary '\0','2024-11-18 00:06:32.850026'),(_binary '',111,112,_binary '',_binary '','2024-11-18 00:28:19.651389'),(_binary '',113,114,_binary '\0',_binary '\0','2024-11-18 01:07:10.076408'),(_binary '',114,115,_binary '',_binary '','2024-11-18 01:19:16.535352'),(_binary '',120,121,_binary '',_binary '\0','2024-11-18 09:25:22.562423'),(_binary '',126,127,_binary '',_binary '','2024-11-18 10:31:46.181764'),(_binary '',128,129,_binary '',_binary '','2024-11-18 11:01:40.413988'),(_binary '',130,131,_binary '\0',_binary '\0','2024-11-18 11:19:49.991156'),(_binary '',131,132,_binary '',_binary '','2024-11-18 11:55:57.073985'),(_binary '\0',132,133,_binary '\0',_binary '\0','2024-11-18 11:56:47.317582'),(_binary '\0',133,134,_binary '\0',_binary '\0','2024-11-18 11:57:41.024705'),(_binary '\0',143,144,_binary '\0',_binary '\0','2024-11-18 12:38:06.089713'),(_binary '\0',144,145,_binary '\0',_binary '\0','2024-11-18 12:38:18.250192'),(_binary '\0',150,151,_binary '\0',_binary '\0','2024-11-18 12:44:50.100785'),(_binary '\0',160,161,_binary '\0',_binary '\0','2024-11-18 13:27:30.708604'),(_binary '\0',162,163,_binary '\0',_binary '\0','2024-11-18 13:27:47.470486'),(_binary '\0',168,169,_binary '\0',_binary '\0','2024-11-18 13:43:24.173944'),(_binary '\0',169,170,_binary '\0',_binary '\0','2024-11-18 13:46:40.055954'),(_binary '\0',170,171,_binary '\0',_binary '\0','2024-11-18 13:47:32.608442'),(_binary '\0',171,172,_binary '\0',_binary '\0','2024-11-18 13:49:33.384268'),(_binary '\0',172,173,_binary '\0',_binary '\0','2024-11-18 13:52:03.259021'),(_binary '',174,175,_binary '\0',_binary '\0','2024-11-18 14:12:04.834250');
/*!40000 ALTER TABLE `quest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 18:57:09
