-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11e204.p.ssafy.io    Database: e204
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sticker`
--

DROP TABLE IF EXISTS `sticker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sticker` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sticker`
--

LOCK TABLES `sticker` WRITE;
/*!40000 ALTER TABLE `sticker` DISABLE KEYS */;
INSERT INTO `sticker` VALUES (1,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-1.png'),(2,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-2.png'),(3,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-3.png'),(4,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-4.png'),(5,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-5.png'),(6,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-6.png'),(7,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-7.png'),(8,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-8.png'),(9,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-9.png'),(10,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-10.png'),(11,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-11.png'),(12,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-12.png'),(13,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-13.png'),(14,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-14.png'),(15,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-15.png'),(16,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-16.png'),(17,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-17.png'),(18,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-18.png'),(19,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-19.png'),(20,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-20.png'),(21,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-21.png'),(22,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-22.png'),(23,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-23.png'),(24,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-24.png'),(25,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-25.png'),(26,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-26.png'),(27,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-27.png'),(28,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-28.png'),(29,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-29.png'),(30,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-30.png'),(31,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-31.png'),(32,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-32.png'),(33,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-33.png'),(34,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-34.png'),(35,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-35.png'),(36,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-36.png'),(37,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-37.png'),(38,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-38.png'),(39,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-39.png'),(40,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-40.png'),(41,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-41.png'),(42,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-42.png'),(43,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-43.png'),(44,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-44.png'),(45,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-45.png'),(46,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-46.png'),(47,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-47.png'),(48,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-48.png'),(49,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-49.png'),(50,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-50.png'),(51,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-51.png'),(52,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-52.png'),(53,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-53.png'),(54,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-54.png'),(55,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-55.png'),(56,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-56.png'),(57,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-57.png'),(58,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-58.png'),(59,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-59.png'),(60,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-60.png'),(61,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-61.png'),(62,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-62.png'),(63,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-63.png'),(64,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-64.png'),(65,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-65.png'),(66,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-66.png'),(67,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-67.png'),(68,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-68.png'),(69,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-69.png'),(70,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-70.png'),(71,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-71.png'),(72,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-72.png'),(73,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-73.png'),(74,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-74.png'),(75,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-75.png'),(76,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-76.png'),(77,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-77.png'),(78,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-78.png'),(79,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-79.png'),(80,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-80.png'),(81,50,'https://sjsbucket.s3.ap-northeast-2.amazonaws.com/free-icon-81.png');
/*!40000 ALTER TABLE `sticker` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 18:57:03
