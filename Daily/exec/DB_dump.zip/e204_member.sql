-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11e204.p.ssafy.io    Database: e204
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `family_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5vf4v55ua48a7hcwomy7bhxpm` (`family_id`),
  CONSTRAINT `FK5vf4v55ua48a7hcwomy7bhxpm` FOREIGN KEY (`family_id`) REFERENCES `family` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (3,5,'2024-11-07 00:23:16.000000','sample_image.jpg','John Doe'),(4,7,'2024-11-13 10:57:00.358365','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/bf31df42-1292-49cd-913a-5e7a2cf3ed5a.jpg','tah'),(7,11,'2024-11-13 23:15:46.282447','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/47cdce6c-e6b6-4c79-ba20-dfbeaa188052.jpg','띵코'),(8,12,'2024-11-13 23:16:23.172543','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/ab430c74-5513-473b-8ef7-bb91607ddad0.jpg','bada'),(6,16,'2024-11-14 12:02:46.196832','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/56a4da4e-47b1-4a38-bd83-681fb12c8980.jpg','러ㅓ러거가가가가다ㅏㄷ다ㅏㅏ다다다다ㅏ랄'),(8,17,'2024-11-14 12:21:14.139257','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/8fdfdf66-a97e-442e-872b-5479ca7e5682.jpg','치킨'),(6,18,'2024-11-14 12:44:58.042782','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/60ed48ec-8315-4314-b2de-4eaaa2e06898.jpg','훈민정음음'),(1,25,'2024-11-15 09:52:36.833530','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/c8181bb2-5620-4980-905c-d1bf37f1be1b.jpg','이준이'),(10,27,'2024-11-15 09:52:53.982445','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/da105dbe-3487-42dd-b66f-e8b88acf7b5a.jpg','Happy'),(10,28,'2024-11-15 09:53:15.980192','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/bc376d59-731a-48cb-808b-b5ba0ca84cfe.jpg','명성'),(11,30,'2024-11-15 10:06:07.906555','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/261b128b-4251-4773-9872-09f6cdfeabeb.jpg','Happy'),(11,31,'2024-11-15 10:06:18.215499','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/aeb84fe1-40cf-4403-8974-cf94d5006699.jpg','Sad'),(11,32,'2024-11-15 10:06:27.255362','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/105b514c-79d8-4687-bdb4-c6383ddb11a4.jpg','해꿍'),(9,35,'2024-11-15 11:14:10.548872','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/4c952c8c-b553-456c-a494-feb37921b2e2.jpg','wrojg'),(10,36,'2024-11-15 11:21:32.903432','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/8288c29d-5bb0-43c7-af48-4d40017fc957.jpg','훈민정음'),(12,82,'2024-11-17 02:34:08.526728','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/1724862f-17d6-46cc-8744-20617346b07b.jpg','123'),(12,83,'2024-11-17 04:37:08.146120','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/dcd8236a-a4c6-4255-9059-60ed939c5855.jpg','asd'),(12,85,'2024-11-17 16:55:14.840494','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/bd703dc1-b548-4923-bce5-0dc2013bf4ea.jpg','th'),(12,86,'2024-11-17 16:56:54.015503','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/2bb4db68-818d-4984-940b-e676bdf59e11.jpg','th1'),(13,93,'2024-11-17 18:21:47.640251','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/5ce45a79-0be4-4612-b631-1cad1218e969.jpg','a1123'),(13,94,'2024-11-17 18:21:56.718619','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/f64859e2-f9c2-40bb-856b-cd039dc505e0.jpg','a3'),(14,96,'2024-11-17 21:55:39.835244','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/706beeb9-afa9-486b-8cf8-c786231b1560.jpg','훈민정음'),(15,110,'2024-11-18 00:06:32.836546','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/a9d05ba5-85bf-4698-b0f5-4c1e7549d11e.jpg','gg'),(16,112,'2024-11-18 00:28:19.639122','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/27b2c89a-6a35-41aa-a840-cbcaafb0d8a2.jpg','s'),(16,114,'2024-11-18 01:07:10.063497','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/2214574a-c32a-483b-ae55-348fe06040c2.jpg','suuug'),(16,115,'2024-11-18 01:19:16.524420','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/947f4528-6998-4d31-bd4e-a315db7f9109.jpg','asdsa'),(1,121,'2024-11-18 09:25:22.551221','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/c617dc3d-ee3a-4d43-8908-8ffa4c89f3dd.jpg','esggg'),(1,127,'2024-11-18 10:31:46.164533','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/94560e07-f7e7-46a6-8c23-1165b7f8c344.jpg','안녕안녕안'),(9,129,'2024-11-18 11:01:40.384067','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/8d0cbf22-1602-43c5-9b78-ebffe765a637.jpg','Sad'),(9,131,'2024-11-18 11:19:49.978161','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/434e80e8-7aae-499b-879a-c3285fd88f16.jpg','Happy'),(20,132,'2024-11-18 11:55:57.060205','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/540415e3-c441-496d-a4f1-d3e3fdc364ad.jpg','건민'),(20,133,'2024-11-18 11:56:47.302516','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/f7c598da-827f-40c7-8cdb-a48033d88aec.jpg','안녕'),(20,134,'2024-11-18 11:57:41.011860','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/55952e02-15db-402c-a073-cdc25477680a.jpg','ㅎㅇ'),(26,144,'2024-11-18 12:38:06.079153','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/73f37eec-a7e5-4839-ab88-e6a5e045ce30.jpg','jen'),(26,145,'2024-11-18 12:38:18.237620','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/15b9ff2e-b109-44d8-a862-92be31c1c8de.jpg','dkfbd'),(26,151,'2024-11-18 12:44:50.089133','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/40206dd0-2778-494e-b441-3f98a1c99628.jpg','hddjj'),(1,161,'2024-11-18 13:27:30.696575','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/0f00257f-643d-4562-a991-59714fc434aa.jpg','asd'),(27,163,'2024-11-18 13:27:47.456892','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/970f9ccc-6952-4238-8500-46bc5045f9a3.jpg','zxczx'),(26,169,'2024-11-18 13:43:24.162581','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/2a7e46dc-24ad-40b4-9c54-a0f97509f69c.jpg','yvx'),(28,170,'2024-11-18 13:46:40.044456','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/f3e82f8a-efbf-4fd9-b4a5-f332ec22010a.jpg','jsnfm'),(28,171,'2024-11-18 13:47:32.594654','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/019f8128-2ecd-40a0-9bb0-65bab959eb5b.jpg','ooqwl'),(28,172,'2024-11-18 13:49:33.372119','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/0da31147-f5ab-4281-94bb-02ca88f65163.jpg','hdjxm'),(28,173,'2024-11-18 13:52:03.244572','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/1ac4613f-d086-4990-8dfc-8d64e8246570.jpg','hsidj'),(9,175,'2024-11-18 14:12:04.822983','https://sjsbucket.s3.ap-northeast-2.amazonaws.com/8e727645-a910-4545-ad9f-f9f93057856a.jpg','ㄷ릊룾러');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 18:57:09
